(function($){"use strict"
$('.datepicker-default').pickadate();})(jQuery);